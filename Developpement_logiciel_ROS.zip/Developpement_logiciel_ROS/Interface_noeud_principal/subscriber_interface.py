########
# Ce noeud joue le role de noeud principal , il est abonné a tous les topics des capteurs et envoie les commandes aux servos en fonction de celles ci
# c'est aussi ce noeud qui gère l'interface et l'affichage en temps réel des donnes grace a la bibliotheque Tkinter .
# Pour envoyer les commandes aux 2 servos , le noeud publie sur 2 topics Cap et Vent qui gére respectivement la voile et le safran en fonction du cap et de la direction du vent .
# La formule de commande est la suivante angle servo voile = cap/2 , angle servo safran = direction vent / 2 .
# Le noeud effectue les calculs lui meme et envoie directement le résultat du calcul qui est l'angle auquel le servo va devoir se placer
#######

import tkinter as tk
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Float32
import RPi.GPIO as GPIO
import threading
import pigpio

class interface(Node):
	def __init__(self):
		super().__init__('interface') # nom du noeud principal
		self.list_enviro =['0','0','0'] # liste pour stockage des données de la bme280 en temps réel
		self.list_gyro =['0','0','0'] # liste pour stockage des données de la mpu9250 en temps réel
		self.list_gps =['0','0','0'] # liste pour stockage des données du gps en temps réel
		self.list_servo =['position servo1 : 90°','position servo2 : 90°'] # # liste pour stockage de la position des servos en temps réel
		self.root = tk.Tk() # initialisation fenetre tkinter
		self.width = self.root.winfo_screenwidth() # largeur de l'ecran
		self.height = self.root.winfo_screenheight() # longueur de l'ecran
		self.canvas = tk.Canvas(self.root, width=self.width/1.5, height=self.height/1.5) # creation du canva qui affiche les donnes
		self.i=0 # initialisation variables afin de gérer les evenements potentiels
		self.pwm = pigpio.pi() 
		self.pwm2 = pigpio.pi()
		self.servo_pin1 = 12 # valeur du port gpio ou le servo 1 est branché
		self.servo_pin2 = 18 # valeur du port gpio ou le servo 2 est branché
		self.button_width = self.width//101 # taille du bouton
		self.button_height = self.height//202
		self.keep_square = False
		self.servo = False
		self.affichage_carres = False
		self.boutons_servomoteur_creés = False
		self.button_list = []
		self.angle1 = 1500 # stockage de la valeur 90° traduite pour la bibliotheque pigpio.pi
		self.angle2 = 1500
		self.angle_decale = 11.1 # ici 11.1 equivaut a un degré de rotation pour un servomoteur
		self.publisher_servo1 = self.create_publisher(String, 'cap', 10) # topic d'envoi de la commande pour le servo qui gere la voile
		self.publisher_servo2 = self.create_publisher(String, 'vent', 10) # topic d'envoi de la commande pour le servo qui gere le safran

        # abonnement au topic temperature et reception des donnes du topic dans la fonction self.temperature
		self.subscription_temp = self.create_subscription(
		    String,
		    'temperature',
		    self.temperature,
		    10)
		self.subscription_temp
        

        # abonnement au topic humidite et reception des donnes du topic dans la fonction self.humidite
		self.subscription_humi = self.create_subscription(
		    String,
		    'humidite',
		    self.humidite,
		    10)
		self.subscription_humi


        # abonnement au topic pression  et reception des donnes du topic dans la fonction self.pression
		self.subscription_press = self.create_subscription(
		    String,
		    'pression',
		    self.pression,
		    10)
		self.subscription_press


        # abonnement au topic roulis et reception des donnes du topic dans la fonction self.roulis
		self.subscription_roulis = self.create_subscription(
		    String,
		    'roulis',
		    self.roulis,
		    10)
		self.subscription_roulis


        # abonnement au topic tangage et reception des donnes du topic dans la fonction self.tangage
		self.subscription_tangage = self.create_subscription(
		    String,
		    'tangage',
		    self.tangage,
		    10)
		self.subscription_tangage


        # abonnement au topic lacet et reception des donnes du topic dans la fonction self.lacet
		self.subscription_lacet = self.create_subscription(
		      String,
		    'lacet',
		    self.lacet,
		    10)
		self.subscription_lacet


        # abonnement au topic latitude et reception des donnes du topic dans la fonction self.latitude
		self.subscription_latitude = self.create_subscription(
		      String,
		    'latitude',
		    self.latitude,
		    10)
		self.latitude


        # abonnement au topic longitude et reception des donnes du topic dans la fonction self.longitude
		self.subscription_longitude = self.create_subscription(
		      String,
		    'longitude',
		    self.longitude,
		    10)
		self.longitude


        # abonnement au topic vitesse et reception des donnes du topic dans la fonction self.vitesse
		self.subscription_vitesse = self.create_subscription(
		      String,
		    'vitesse',
		    self.vitesse,
		    10)
		self.vitesse


        self.subscription_vent = self.create_subscription(
            String,
            'vent',
            self.vent,
            10)
        self.vent


    # cette fonction prend un parametre angle de la plage 0 a 180° et le transforme pour correspondre a la plage 500 - 2500 de la bibliotheque pigpio
	def traduction_angle(self , angle):
		if 500 + angle*self.angle_decale<500:
			return 500
		elif 500 + angle*self.angle_decale>2500:
			return 2500
		else:
			return 500 + angle*self.angle_decale

    # recoit la temperature en temps reel et l'ajoute a la liste list_enviro pour l'afficher sur l'interface
	def temperature(self, msg):
		temp = msg.data
		self.list_enviro[0]=temp
    
    # recoit l'humidite  en temps reel et l'ajoute a la liste list_enviro pour l'afficher sur l'interface
	def humidite(self, msg):
		humi = msg.data
		self.list_enviro[1]=humi

    # recoit la pression en temps reel et l'ajoute a la liste list_enviro pour l'afficher sur l'interface
	def pression(self, msg):
		press = msg.data
		self.list_enviro[2]=press

    # recoit l'angle de roulis en temps reel et l'ajoute a la liste list_gyro pour l'afficher sur l'interface
	def roulis(self, msg):
		roll = msg.data
		self.list_gyro[0]=roll

    # recoit l'angle de tangage en temps reel et l'ajoute a la liste list_gyro pour l'afficher sur l'interface
	def tangage(self, msg):
		pitch = msg.data
		self.list_gyro[1]=pitch

    # recoit le lacet en temps reel et l'ajoute a la liste list_gyro pour l'afficher sur l'interface
	# cette fonction recoit le lacet et effectue le calcul necessaire sur le lacet recu pour l'envoyer sur le topic cap afin qu'un moteur le lise et modifie son angle

	def lacet(self, msg):
		split = msg.data.split(": ")
		self.list_gyro[2]=msg.data
		angle_ntrad = float(split[1])
		#angle_ntrad = int(angle_ntrad)
		angle_div = angle_ntrad//2
		angle_send = self.traduction_angle(angle_div)
		affich = (angle_send-500)//11.1
		self.angle1 = affich
		send = f"Position servo1 : {str(affich)}°"
		self.list_servo[0]=send
		msg.data = str(angle_send)
		self.publisher_servo1.publish(msg)

    # recoit la latitude en temps reel et l'ajoute a la liste list_gps pour l'afficher sur l'interface
	def latitude(self, msg):
		self.list_gps[0]=msg.data

     # recoit la longitude en temps reel et l'ajoute a la liste list_gps pour l'afficher sur l'interface
	def longitude(self, msg):
		self.list_gps[1]=msg.data

     # recoit la vitesse en temps reel et l'ajoute a la liste list_gps pour l'afficher sur l'interface
	def vitesse(self, msg):
		self.list_gps[2]=msg.data


    def vent(self, msg):
        split = msg.data.split(": ")
        angle_ntrad = float(split[1])
        #angle_ntrad = int(angle_ntrad)
        angle_div = angle_ntrad//2
        angle_send = self.traduction_angle(angle_div)
        affich = (angle_send-500)//11.1
        self.angle1 = affich
        send = f"Position servo1 : {str(affich)}°"
        self.list_servo[0]=send
        msg.data = str(angle_send)
        self.publisher_servo2.publish(msg)

    # comme le capteur de vent ne fonctionne pas , notre interface nous laisse la possibilité de modifier l'angle du servo 2 et d'ajouter sa position a la liste_servo afin de l'afficher en temps reel
    # un clic sur le bouton incremente l'angle de 10° , ainsi le servo effectue une rotation de 10° dans le sens désiré
	def move_servo1_g(self):
		self.angle1-=self.angle_decale*10
		self.pwm.set_servo_pulsewidth(12, self.angle1)
		data = f"Position servomoteur 1 = {(self.angle1-500)//self.angle_decale}:Position servomoteur 2 = {(self.angle2-500)//self.angle_decale}"
		liste = data.split(":")
		self.list_servo[0]= liste[0]
		self.list_servo[1]= liste[1]

	def move_servo1_d(self):
		self.angle1+=self.angle_decale*10
		self.pwm.set_servo_pulsewidth(12, self.angle1)
		data = f"Position servomoteur 1 = {(self.angle1-500)//self.angle_decale}:Position servomoteur 2 = {(self.angle2-500)//self.angle_decale}"
		liste = data.split(":")
		self.list_servo[0]= liste[0]
		self.list_servo[1]= liste[1]

	def move_servo2_g(self):
		self.angle2-=self.angle_decale*10
		self.pwm2.set_servo_pulsewidth(18, self.angle2)
		data = f"Position servomoteur 1 = {(self.angle1-500)//self.angle_decale}:Position servomoteur 2 = {(self.angle2-500)//self.angle_decale}°"
		liste = data.split(":")
		self.list_servo[0]= liste[0]
		self.list_servo[1]= liste[1]

	def move_servo2_d(self):
		self.angle2+=self.angle_decale*10
		self.pwm2.set_servo_pulsewidth(18, self.angle2)
		data = f"Position servomoteur 1 = {(self.angle1-500)//self.angle_decale}:Position servomoteur 2 = {(self.angle2-500)//self.angle_decale}°"
		liste = data.split(":")
		self.list_servo[0]= liste[0]
		self.list_servo[1]= liste[1]

        
    #cette fonction permet l'affichage des donnes dans les carres de l'interface 
    # elle ajoute les donnees du parametre data au rectangle passé en parametre
	def read_file_and_display(self,data, rectangle, title, font):

		try:
			x1, y1, x2, y2 = self.canvas.coords(rectangle)
			# Supprimer le texte précédent
			self.canvas.delete(f"text_{rectangle}")
			# Afficher le contenu du fichier comme texte sur le rectangle
			text_x = (x1 + x2) / 2
			text_y = (y1 + y2) / 2
			self.canvas.create_text(text_x, text_y, text=data, tags=(f"text_{rectangle}",), font=("Arial", font))
		except FileNotFoundError:
			# Afficher un message si le fichier est introuvable
			self.canvas.delete(f"text_{rectangle}")
			text_x = (x1 + x2) / 2
			text_y = (y1 + y2) / 2
			self.canvas.create_text(text_x, text_y, text="Fichier introuvable", tags=(f"text_{rectangle}",), font=("Arial", font))

		# Afficher le nom du carré au-dessus
		title_x = (x1 + x2) / 2
		title_y = y1 - 20
		self.canvas.create_text(title_x, title_y, text=title, fill="white")



    #cette fonction permet la creation de 4 carres distinct placés respectivement aux coins du canva .
    # l'appel de la fonction read_file_and_display dans cette fonction permet aux carres d'avoir dans leurs centres les valeurs des capteurs en temps reel .
	def create_squares2(self):
		global squares_created
		# Déclaration de la liste de boutons comme variable globale
		self.affichage_carres=False
		self.boutons_servomoteur_creés =True
		# Supprimer les boutons d'affichage s'ils sont déjà présents
		if self.affichage_carres:
			self.canvas.delete("affichage_carres")
			self.affichage_carres = False

		# Supprimer les boutons de servomoteur s'ils sont déjà présents
		if self.boutons_servomoteur_creés:
			for button in self.button_list:
				button.destroy()
			self.button_list = []  # Réinitialisation de la liste de boutons
			self.boutons_servomoteur_creés = False
		# Obtenir les dimensions du canevas
		canvas_width = self.canvas.winfo_width()
		canvas_height = self.canvas.winfo_height()

		# Calculer les dimensions des carrés proportionnellement à la taille du canevas
		square_size = min(canvas_width, canvas_height) * 0.4  # Utiliser 40% de la taille du canevas pour chaque carré
		margin_x = canvas_width * 0.05  # Marge horizontale
		margin_y = canvas_height * 0.05  # Marge verticale

		# Supprimer l'image de fond
		self.canvas.delete("background_image")
		# Créer les carrés aux coins de l'interface
		rectangle1 = self.canvas.create_rectangle(margin_x, margin_y, margin_x + square_size, margin_y + square_size, fill="red")
		rectangle2 = self.canvas.create_rectangle(canvas_width - margin_x - square_size, margin_y, canvas_width - margin_x, margin_y + square_size, fill="yellow")
		rectangle3 = self.canvas.create_rectangle(margin_x, canvas_height - margin_y - square_size, margin_x + square_size, canvas_height - margin_y, fill="green")
		rectangle4 = self.canvas.create_rectangle(canvas_width - margin_x - square_size, canvas_height - margin_y - square_size, canvas_width - margin_x, canvas_height - margin_y, fill="green")

		# Lire le contenu des fichiers et les afficher dans les carrés correspondants
		
		time.sleep(1)
		self.read_file_and_display('\n'.join(self.list_enviro), rectangle1, "BME280" , 12)
		self.read_file_and_display('\n'.join(self.list_gyro), rectangle2, "GYROCOMPAS" , 12)
		self.read_file_and_display('\n'.join(self.list_gps), rectangle3, "GPS" , 10)
		self.read_file_and_display('\n'.join(self.list_servo), rectangle4, "Position Servo" , 10)
		squares_created = True


    # met la variable self.keep_square a true et self.servo a false
    # sert a effacer les boutons si on appuie sur le bouton affichage
	def put_square_true(self):
		self.keep_square=True
		self.servo = False

	def put_servo_true(self):
		self.servo = True
		self.keep_square = False

    # Cette fonction permet l'affichage des boutons qui servent aux mouvements des servomoteurs
	def mouvement_servomoteur(self):
		if self.affichage_carres:
			self.canvas.delete("affichage_carres")
			self.affichage_carres = False

	# Supprimer les boutons de servomoteur s'ils sont déjà présents
		if self.boutons_servomoteur_creés:
			for button in self.button_list:
				button.destroy()
			self.button_list = []  # Réinitialisation de la liste de boutons
			self.boutons_servomoteur_creés = True

		# Créer les 4 boutons sur le canvas avec une marge de 10 pixels
		margin = 10
		canvas_width = self.canvas.winfo_width()
		canvas_height = self.canvas.winfo_height()
		new_margin_x = min(canvas_width, canvas_height) // 3
		new_margin_y = min(canvas_width, canvas_height) // 3
		if self.servo == True:

			button1 = tk.Button(self.root, text="Mouvement servomoteur 1 <--", width=self.button_width+new_margin_x//9, height=self.button_height , command=self.move_servo1_g)
			button1.place(x=canvas_width // 2 - new_margin_x*2, y=canvas_height // 2 - new_margin_y)
            #La commande self.move_servo1_g permet de faire tourner le moteur 1 de 10° vers la gauche

			button2 = tk.Button(self.root, text="Mouvement servomoteur 2 <--", width=self.button_width+new_margin_x//9, height=self.button_height , command=self.move_servo2_g)
			button2.place(x=canvas_width // 2 - new_margin_x*2, y=canvas_height // 2 + new_margin_y)
            #La commande self.move_servo2_g permet de faire tourner le moteur 2 de 10° vers la gauche

			button3 = tk.Button(self.root, text="Mouvement servomoteur 1 -->", width=self.button_width+new_margin_x//9, height=self.button_height , command=self.move_servo1_d)
			button3.place(x=canvas_width // 2 + new_margin_x//2.2, y=canvas_height // 2 - new_margin_y )
            #La commande self.move_servo1_d permet de faire tourner le moteur 1 de 10° vers la droite

			button4 = tk.Button(self.root, text="Mouvement servomoteur 2 -->", width=self.button_width+new_margin_x//9, height=self.button_height,command=self.move_servo2_d)
			button4.place(x=canvas_width // 2 + new_margin_x//2.2, y=canvas_height // 2 + new_margin_y)
            #La commande self.move_servo2_d permet de faire tourner le moteur 2 de 10° vers la droite


			self.servo=False
		self.button_list.extend([button1, button2, button3, button4])
		self.boutons_servomoteur_creés = True


	def start_inter(self):
		# Initialisation de la variable pour savoir si les carrés ont été créés
		squares_created = False

		# Créer la fenêtre principale

		self.root.title("Interface graphique VirVoile")

		# Créer un canevas pour dessiner les carrés


		#canvas.bind("<Left>", self.create_squares)
		self.canvas.pack(expand=True, fill='both')
		self.root.resizable(False,False)
		#self.create_squares2()

		# Charger l'image de fond

        # affichage des boutons au lancement du programme
		if self.i==0:
			button1 = tk.Button(self.root, text="Servomoteur", command=self.put_servo_true, width=self.button_width, height=self.button_height)
			button1.place(relx=0.5, rely=0.4, anchor="center")

			button2 = tk.Button(self.root, text="Affichage Capteurs", command=self.put_square_true, width=self.button_width, height=self.button_height)
			button2.place(relx=0.5, rely=0.6, anchor="center")



		if self.keep_square:
			self.create_squares2()

		if self.servo:
			self.mouvement_servomoteur()


		self.i+=1
		self.root.after(1000, self.start_inter)
        #la fonction after permet d'effectuer une recursion sur la fonction self.start_inter afin de pouvoir combiner ros et tkinter , la présence de 2 boucles infinis
        # dans les 2 fonctions ne permet pas d'autres solutions .
	# Bouton pour le mouvement du servo moteur


	# Démarrer la boucle principale


def main(args=None):
    rclpy.init(args=args)
    node = interface()
    t1 = threading.Thread(target=rclpy.spin , args = [node])
    t1.start()
    node.start_inter()
    node.root.mainloop()
    t1.join()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
