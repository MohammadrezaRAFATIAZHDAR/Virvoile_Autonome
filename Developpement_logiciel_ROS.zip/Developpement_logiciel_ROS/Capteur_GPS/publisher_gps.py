import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from serial import Serial
import time
import math

class GPSNode(Node):
    def __init__(self):
        super().__init__('gps_node')
        self.publisher_vitesse = self.create_publisher(String, 'vitesse', 10)
        self.publisher_latitude = self.create_publisher(String, 'latitude', 10)
        self.publisher_longitude = self.create_publisher(String, 'longitude', 10)
        self.prec_latitude = -1
        self.prec_longitude = -1
        self.prec_timestamp = -1

    def decode_gpgll(self,gpgll_line):
        # Vérifier que la ligne commence par "$GPGLL"
        if not gpgll_line.startswith("$GPGLL"):
            return None, None

        # Séparer les éléments de la ligne
        elements = gpgll_line.split(',')

        # Vérifier que la ligne contient suffisamment d'éléments
        if len(elements) < 6:
            return None, None

        # Extraire la latitude et la longitude
        latitude_dmm = elements[1]
        longitude_dmm = elements[3]

        # Conversion de la latitude et la longitude en décimales
        try:
            latitude_degrees = float(latitude_dmm[:2])
            latitude_minutes = float(latitude_dmm[2:])
            latitude_decimal = latitude_degrees + latitude_minutes / 60.0

            longitude_degrees = float(longitude_dmm[:3])
            longitude_minutes = float(longitude_dmm[3:])
            longitude_decimal = longitude_degrees + longitude_minutes / 60.0

            # Vérifier l'indication de l'hémisphère
            if elements[2] == 'S':
                latitude_decimal *= -1
            if elements[4] == 'W':
                longitude_decimal *= -1

            return latitude_decimal, longitude_decimal
        except ValueError:
            return None, None
        print("Erreur lors du décodage de la ligne GPGLL.")
        
   

    def haversine(self,lat1, lon1, lat2, lon2):
        R = 6371000  # rayon de la Terre en mètres
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)

        a = math.sin(delta_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        distance = R * c
        return distance

    def calculate_speed(self,latitude,longitude,timestamp):
        distance = self.haversine(self.prec_latitude, self.prec_longitude, latitude,longitude)
        print("distance :", distance)
        diff_temps = timestamp - self.prec_timestamp  # en secondes
        vitesse = distance / diff_temps  # en mètres par seconde


        return vitesse

    def publish_gps_data(self,file_path):
        try:
            with open(file_path, 'r') as file:
                for line in file:
                    if line.startswith("$GPGLL"):
                        print(line)
                    # Supprimer les espaces blancs en début et fin de ligne
                    latitude , longitude = self.decode_gpgll(line)
                    timestamp=time.time()
                    if latitude is not None and longitude is not None:

                        
                        Vitesse = self.calculate_speed(latitude,longitude,timestamp)

                       
                        
                        msg_latitude = String()
                        msg_longitude = String()
                        msg_vitesse = String()
                        msg_latitude.data = f"Latitude:{latitude:.8f}"
                        msg_longitude.data = f"Longitude:{longitude:.8f}"
                        msg_vitesse.data = f"Vitesse:{Vitesse:.2f}"

                        self.publisher_latitude.publish(msg_latitude)
                        self.publisher_longitude.publish(msg_longitude)
                        self.publisher_vitesse.publish(msg_vitesse)

                        self.prec_latitude = latitude
                        self.prec_longitude = longitude
                        self.prec_time = timestamp
                    # Traiter la ligne ici

                    time.sleep(1)
        except FileNotFoundError:
            print("Le fichier spécifié n'a pas été trouvé.")
        except Exception as e:
            print("Une erreur s'est produite :", str(e))

def main(args=None):
    rclpy.init(args=args)
    temp = open("log/log_data/temp_log_gps.txt","w")
    logs = open("log/log_data/log_gps.txt","a+")
    gps_node = GPSNode()
    try:
        gps_node.publish_gps_data("/dev/ttyACM0")
    finally:
        gps_node.destroy_node()
        rclpy.shutdown()
    logs.close()
    temp.close()

if __name__ == '__main__':
    main()

