#!/usr/bin/env python
########
# Le servomoteur 1 qui est chargé de bouger la voile reçoit son angle de rotation par le noeud principal .
# Ce noeud est abonné au topic cap du noeud principal et peut y lire la donnée du magnetometre , son angle est égal au cap magnetique / 2
# Le mouvement du servomoteur s'effectue grace a la bibliotheque pigpio
#######
import random
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Float32
import pigpio
import time


class BMESubscriber(Node):
    def __init__(self):
        super().__init__('servo_voile')
        #Abonnement du noeud au topic cap afin de récolter l'angle de rotation
        self.subscription = self.create_subscription(
            String,
            'cap',
            self.read_servo_angle, # fonction qui va recevoir les données du topic ( l'angle de rotation )
            10)
        self.subscription
        self.subscription  # Timer to publish servo angle every second
        self.pwm = pigpio.pi() # Initialisation objet pigpio afin de pouvoir modifier l'angle du moteur
        self.servo_pin = 12 # port gpio sur lequel le moteur est branché
        # Set PWM frequency to 50 Hz

    #Cette fonction recolte l'angle dans le parametre message , cast cet angle en int afin de l'envoyer dans la methode pwm.set_servo_pulsewidth afin de mettre le servomoteur a l'angle souhaité
    def read_servo_angle(self , msg):
        angle = float(msg.data)
        data = f"Angle recu : {(angle-500)//11.1}"
        print("Angle recu = " , data)
        self.pwm.set_servo_pulsewidth(12, angle)



def main(args=None):
    rclpy.init(args=args)
    bme_subscriber = BMESubscriber()
    rclpy.spin(bme_subscriber)
    bme_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
