#!/usr/bin/env python
########
# Ce code permet de bouger le servo moteur 2 ( safran ) apres reception de l'angle sur le topic vent
#######


import random
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Float32
import pigpio
import time


class BMESubscriber(Node):
    def __init__(self):
        super().__init__('servo_safran')
        # abonnement du noeud au topic vent , la direction du vent est accessible via la fonction read_servo_angle
        self.subscription = self.create_subscription(
            String,
            'vent',
            self.read_servo_angle,
            10)
        self.subscription
        self.subscription  # Timer to publish servo angle every second
        self.pwm = pigpio.pi()
        self.servo_pin = 18 # Port gpio sur lequel le servo 2 est branché
        # Set PWM frequency to 50 Hz
        self.angle = 500

    # Cette fonction recoit l'angle a appliquer sur le servo2 ( angle calculé par le noeud principal )
    def read_servo_angle(self , msg):

        print("MESSAGE = " , msg.data)
        angle = float(msg.data)
        print(angle)
        self.pwm.set_servo_pulsewidth(12, int(angle))



        #self.get_logger().info(f"Temperature = {msg.data} °C")

def main(args=None):
    rclpy.init(args=args)
    bme_subscriber = BMESubscriber()
    rclpy.spin(bme_subscriber)
    bme_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
