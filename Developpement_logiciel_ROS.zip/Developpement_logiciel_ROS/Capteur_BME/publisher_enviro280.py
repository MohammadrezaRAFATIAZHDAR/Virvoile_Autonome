#######   MGMATDEV
# Le capteur BME280 permet de collecter 3 données : la Pression , l'Humidité et la température .
# Ce code permet au capteur BME280 de publier ses 3 données sur 3 topics appelés respectivement : pression , humidité , temperature
# La publication sur ces topics permettra la lecture de ces données par un autre noeud qui joue le role de subsriber principal afin d'effectuer les calculs pour les servos .
# La plupart de ces lignes de codes permettent de traduire les données envoyés par la BME280 sur le bus I2C afin de pouvoir accéder à ces données , il n'est pas nécessaire
# de comprendre toutes ces lignes de codes , pour cette raison ce code ne sera commenter que dans les parties utilisant ROS .
########

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time
import smbus
from ctypes import c_short
from ctypes import c_byte
from ctypes import c_ubyte

def getShort(data, index):
# return two bytes from data as a signed 16-bit value
  return c_short((data[index+1] << 8) + data[index]).value

def getUShort(data, index):
# return two bytes from data as an unsigned 16-bit value
  return (data[index+1] << 8) + data[index]

def getChar(data,index):
  # return one byte from data as a signed char
  result = data[index]
  if result > 127:
    result -= 256
  return result

def getUChar(data,index):
  # return one byte from data as an unsigned char
  result =  data[index] & 0xFF
  return result

class enviro_publisher(Node):
    def __init__(self):
        super().__init__('enviro_publisher')
        self.publisher_temp = self.create_publisher(String, 'temperature', 10)
        self.publisher_press = self.create_publisher(String, 'pression', 10)
        self.publisher_humi = self.create_publisher(String, 'humidite', 10)

        #Initialise time start of process
        #self.time_start = time.time()
        # Initialise le bus I2C
        self.bus = smbus.SMBus(1)  # Changez le numéro de bus selon votre configuration




    # Cette fonction renvoie un tuple qui contient toutes les données du capteur ( temperature , humidite , pression )
    def read_bme280_data(self):
        # Initialisez l'adresse I2C du capteur BME280 (par défaut : 0x76)
        addr = 0x76
        bus = self.bus
          # Register Addresses
        REG_DATA = 0xF7
        REG_CONTROL = 0xF4
        REG_CONFIG  = 0xF5

        REG_CONTROL_HUM = 0xF2
        REG_HUM_MSB = 0xFD
        REG_HUM_LSB = 0xFE

        # Oversample setting - page 27
        OVERSAMPLE_TEMP = 2
        OVERSAMPLE_PRES = 2
        MODE = 1

        # Oversample setting for humidity register - page 26
        OVERSAMPLE_HUM = 2
        bus.write_byte_data(addr, REG_CONTROL_HUM, OVERSAMPLE_HUM)

        control = OVERSAMPLE_TEMP<<5 | OVERSAMPLE_PRES<<2 | MODE
        bus.write_byte_data(addr, REG_CONTROL, control)

        # Lire les données de température, d'humidité et de pression
        block = self.bus.read_i2c_block_data(addr, 0xF7, 8)
        # print(block)
        pres_raw = (block[0] << 16 | block[1] << 8 | block[2]) >> 4
        temp_raw = (block[3] << 16 | block[4] << 8 | block[5]) >> 4
        hum_raw = block[6] << 8 | block[7]

        # Read blocks of calibration data from EEPROM
        # See Page 22 data sheet
        cal1 = self.bus.read_i2c_block_data(addr, 0x88, 24)
        cal2 = self.bus.read_i2c_block_data(addr, 0xA1, 1)
        cal3 = self.bus.read_i2c_block_data(addr, 0xE1, 7)

        # Convert byte data to word values
        dig_T1 = getUShort(cal1, 0)
        dig_T2 = getShort(cal1, 2)
        dig_T3 = getShort(cal1, 4)

        dig_P1 = getUShort(cal1, 6)
        dig_P2 = getShort(cal1, 8)
        dig_P3 = getShort(cal1, 10)
        dig_P4 = getShort(cal1, 12)
        dig_P5 = getShort(cal1, 14)
        dig_P6 = getShort(cal1, 16)
        dig_P7 = getShort(cal1, 18)
        dig_P8 = getShort(cal1, 20)
        dig_P9 = getShort(cal1, 22)

        dig_H1 = getUChar(cal2, 0)
        dig_H2 = getShort(cal3, 0)
        dig_H3 = getUChar(cal3, 2)

        dig_H4 = getChar(cal3, 3)
        dig_H4 = (dig_H4 << 24) >> 20
        dig_H4 = dig_H4 | (getChar(cal3, 4) & 0x0F)

        dig_H5 = getChar(cal3, 5)
        dig_H5 = (dig_H5 << 24) >> 20
        dig_H5 = dig_H5 | (getUChar(cal3, 4) >> 4 & 0x0F)

        dig_H6 = getChar(cal3, 6)

        #Calcul temperature
        var1 = ((((temp_raw>>3)-(dig_T1<<1)))*(dig_T2)) >> 11
        var2 = (((((temp_raw>>4) - (dig_T1)) * ((temp_raw>>4) - (dig_T1))) >> 12) * (dig_T3)) >> 14
        t_fine = var1+var2
        temperature = float(((t_fine * 5) + 128) >> 8);

        # Calcul pression et ajuste la temperature
        var1 = t_fine / 2.0 - 64000.0
        var2 = var1 * var1 * dig_P6 / 32768.0
        var2 = var2 + var1 * dig_P5 * 2.0
        var2 = var2 / 4.0 + dig_P4 * 65536.0
        var1 = (dig_P3 * var1 * var1 / 524288.0 + dig_P2 * var1) / 524288.0
        var1 = (1.0 + var1 / 32768.0) * dig_P1
        if var1 == 0:
          pressure=0
        else:
          pressure = 1048576.0 - pres_raw
          pressure = ((pressure - var2 / 4096.0) * 6250.0) / var1
          var1 = dig_P9 * pressure * pressure / 2147483648.0
          var2 = pressure * dig_P8 / 32768.0
          pressure = pressure + (var1 + var2 + dig_P7) / 16.0

        # Calcul humidite
        humidity = t_fine - 76800.0
        humidity = (hum_raw - (dig_H4 * 64.0 + dig_H5 / 16384.0 * humidity)) * (dig_H2 / 65536.0 * (1.0 + dig_H6 / 67108864.0 * humidity * (1.0 + dig_H3 / 67108864.0 * humidity)))
        humidity = humidity * (1.0 - dig_H1 * humidity / 524288.0)
        if humidity > 100:
          humidity = 100
        elif humidity < 0:
          humidity = 0


        #print(temperature/100,"C ",humidity,"% ",pressure/100,"hpa")
        return temperature/100.0, humidity, pressure/100


    def publish_environment_data(self,logs,temp):
        while True:
            #
            temperature,humidity,pressure = self.read_bme280_data()
            # Stocke les données du capteur dans 3 variables
            msg_temp = String() # Passage en string pour pouvoir envoyer la donnée sur la topic car la méthode .publish attend un string .
            msg_press = String()
            msg_humi = String()
            msg_temp.data = f"\nTemperature : {temperature}C"
            msg_press.data = f"\nPressure : {pressure:.2f} hPa"
            msg_humi.data = f"\nHumidity : {humidity:.2f}%"
            file_log = f"Données température : {msg_temp.data} \n Données pression : {msg_press.data} \n Données humidité : {msg_humi.data}"
            print(file_log)
            self.publisher_temp.publish(msg_temp) # envoie de la temperature sur le topic temperature
            self.publisher_press.publish(msg_press) # envoie de la pression sur le topic pression
            self.publisher_humi.publish(msg_humi) # envoie de l'humidite sur le topic humidite


            #Ecriture des logs pour avoir une trace d'execution dans un fichier log.txt
            log_data =String()
            log_data = f"{time.ctime(time.time())}{msg_temp.data}{msg_humi.data}{msg_press.data}@\n\n"
            logs.write(log_data)
            temp.write(log_data)
            logs.flush()
            temp.flush()

            # Attend un certain temps avant la prochaine lecture des données
            time.sleep(1)

def main(args=None):
    rclpy.init(args=args)
    node = enviro_publisher()
    temp = open("log/log_data/temp_log_enviro.txt","w") # creation du fichier de log temporaire
    logs = open("log/log_data/log_enviro.txt","a+") # creation du fichier de log permanent
    try:
      node.publish_environment_data(logs,temp)
    finally:
      node.destroy_node()
      rclpy.shutdown()
    logs.close()
    temp.close()


if __name__ == '__main__':
    main()
